import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SantaFactory {

    class Toy {
      float cost = 0;
      String color = "";
      float size = 0;
      String owner = null;
    }
  
    class Doll extends Toy{
      float cost = 25;
    }
  
    class DottedBall extends Toy{
      float cost = 10;
    }
  
    class JumpingRope extends Toy {
      float cost = 15;
    }

    float balance = 200;
    ArrayList<Toy> bag = new ArrayList<Toy>();
    public SantaFactory(ArrayList<String> children) {
        children = new ArrayList<String>();
        addToyToBag(null, null, null);
        bringToChildren();
    }
  
    public void addToyToBag(String factory, String color, String size){
        Toy toy = produce(color);
        if (toy != null) {
            bag.add(toy);
        }
    }

    public void bringToChildren() {
        ArrayList<String> children = new ArrayList<String>();
        children.add("Lacika");
        children.add("Sanyika");
        children.add("Józsika");

        int rnd = (int)Math.floor(Math.random()*(0-children.size()+1)+0);

        int i = 0;
        while (!children.isEmpty() || !bag.isEmpty()) {

            bag[i].owner = children[rnd];
            
            bag.remove(i);
            children.remove(i);
            i++;
        }
    }

    public Toy produce(String Color, float size) {
        int rnd = (int)Math.floor(Math.random()*(0-3)+0);
        Toy toy = new Toy();

        switch (rnd) {
            case 0: toy = new Doll(); break;
            case 1: toy = new DottedBall(); break;
            case 2: toy = new JumpingRope(); break;
        }
        if (this.balance - toy.cost >= 0){
            toy.color = Color;
            this.balance -= toy.cost;
            return toy;
        } else
            return null;
    }

    public Doll produce(String Color) {
        Doll doll = new Doll();
        if (this.balance - doll.cost >= 0){
            doll.color = Color;
            this.balance -= doll.cost;
            return doll;
        } else
            return null;
    }
}

