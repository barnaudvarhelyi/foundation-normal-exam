import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
  static int[][] transposeMatrix(int[][] input) {

    int[][] transposeeMatrix = new int[input.length][input[1].length];

    System.out.println("Printing Matrix without transpose:");  
  
    for (int i = 0; i < input.length; i++){
      for (int j = 0; j < input[i].length; j++) {
        System.out.print(input[i][j] + " ");
      }
      System.out.println();
    }
      
    System.out.println("Printing Matrix after transpose:");     
    for(int i = 0; i < input[0].length; i++){    
      for(int j = 0; j < input.length; j++){    
        System.out.print(input[j][i] + " "); 
        transposeeMatrix[j][i] = input[j][i];
      }    
      System.out.println();   
    }    

    return transposeeMatrix;
  }

  static void outputWordsWithFrequency(String inputName, int frequency, String outputName) {

    String data = "";

    try {
      File file = new File(inputName);
      Scanner reader = new Scanner(file);
      while (reader.hasNextLine()) {
        data = reader.nextLine();
      }
      reader.close();
    } catch (FileNotFoundException e) {
      System.out.println(e);
      e.printStackTrace();
    }

    String[] splited = data.split(" ");
    Arrays.sort(splited);

    Map<String,Integer> wordMap = new HashMap<String,Integer>();

    for ( String word : splited ) {
      Integer oldCount = wordMap.get(word);
      if ( oldCount == null ) {
         oldCount = 0;
      }
      wordMap.put(word, oldCount + 1);
    }

    String wantedWords = "";
    for ( String word : wordMap.keySet() ) {
      if ( wordMap.get(word) == frequency) {
        wantedWords += word;
      }
    }
    String[] output = wantedWords.split(" ");
    Arrays.sort(output);

    try {
        FileWriter wr = new FileWriter(outputName);
        for (String word : output) {
          wr.write(word + " ");
        }
        wr.close();
    } catch (IOException e) {
        System.out.println(e);
    }
  }
  

  public static void main(String[] args) {

    int[][] test = new int[][] {
      new int[] { 1, 2, 3, 4},
      new int[] { 6, 7, 8, 9},
    };
    
    transposeMatrix(test);

    outputWordsWithFrequency(null, 2, "output.txt");


    SantaFactory SantaFactory = new SantaFactory(null);
  }  

}